import csv
import json
from datetime import datetime
import os
import requests
import urllib3
from html.parser import HTMLParser
import re
import requests.adapters
import yaml
from concurrent.futures import ThreadPoolExecutor
from threading import local
from urllib3 import Retry
import tarfile
import xml.etree.ElementTree as ET
import shutil
import argparse
from importlib import resources

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
thread_local = local()


def judge_init():
    directories = [
        'port_workspace',
        'port_workspace/src',
        'port_workspace/download',
        'port_workspace/repo',
        'port_workspace/fix',
    ]

    files = [
        'port_workspace/info.csv',
        'port_workspace/fix.csv',
        'port_workspace/analyse.csv',
        'port_workspace/ros_port_tool.log',
        'port_workspace/fix/cmake.spec',
        'port_workspace/fix/python.spec',

    ]

    for directory in directories:
        if not os.path.isdir(directory):
            return False

    for file_path in files:
        if not os.path.isfile(file_path):
            return False

    return True


def move(input_file_path, output_file_path, fix_path):
    if os.path.exists(output_file_path):
        shutil.move(input_file_path, output_file_path)
    if os.path.exists(fix_path):
        for filename in os.listdir(fix_path):
            source_file = os.path.join(fix_path, filename)
            if os.path.isfile(source_file) and not filename.endswith('.fix'):
                shutil.copy(source_file, output_file_path)


def replace_keywords_and_save_to_new_file(input_file_path, output_file_path, keyword_value_mapping):
    try:
        with open(input_file_path, 'r', encoding='utf-8') as file:
            file_content = file.read()

        if keyword_value_mapping["ROS_ALL_FIX_REQUIRES"] == '':
            if keyword_value_mapping["ROS_PACKAGE_NAME"] in ["ament-cmake-core", "ament-package", "ros-workspace"]:
                lines = file_content.splitlines()
                filtered_lines = [line for line in lines if "ROS_ALL_FIX_REQUIRES" not in line]
                file_content = '\n'.join(filtered_lines)
        else:
            file_content.replace("ROS_ALL_FIX_REQUIRES", '')

        if keyword_value_mapping["ROS_PACKAGE_URL"] == '':
            lines = file_content.splitlines()
            filtered_lines = [line for line in lines if "ROS_PACKAGE_URL" not in line]
            file_content = '\n'.join(filtered_lines)

        for keyword, value in keyword_value_mapping.items():
            file_content = file_content.replace(keyword, value)

        if not os.path.exists(output_file_path):
            os.makedirs(output_file_path)
        output_file = os.path.join(output_file_path, keyword_value_mapping["ROS_PACKAGE_NAME"] + ".spec")
        with open(output_file, 'w', encoding='utf-8') as file:
            file.write(file_content)

        print("关键字替换完成，结果已保存到：" + output_file_path)
    except Exception as e:
        print(f"发生错误：{e}")


def analyse_extra_dependencies(directory):
    target_suffixes = [".BuildRequires", ".Provides", ".Requires", ".test-BuildRequires"]
    dep_dict = {}
    for file in os.listdir(directory):
        full_path = os.path.join(directory, file)
        if os.path.isfile(full_path):
            base_name = os.path.basename(file)
            name, extension = os.path.splitext(base_name)
            if extension in target_suffixes:
                if name not in dep_dict.keys():
                    dep_dict[name] = [[], [], [], [], [], [], []]
                if extension == ".BuildRequires":
                    with open(full_path, 'r', encoding='utf-8') as f:
                        changes = f.readlines()
                        for change in changes:
                            if change.startswith('+'):
                                dep_dict[name][0].append(change[1:].strip())
                            if change.startswith('-'):
                                dep_dict[name][1].append(change[1:].strip())
                if extension == ".Provides":
                    with open(full_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        dep_dict[name][2] = content.strip()
                if extension == ".Requires":
                    with open(full_path, 'r', encoding='utf-8') as f:
                        changes = f.readlines()
                        for change in changes:
                            if change.startswith('+'):
                                dep_dict[name][3].append(change[1:].strip())
                            if change.startswith('-'):
                                dep_dict[name][4].append(change[1:].strip())
                if extension == ".test-BuildRequires":
                    with open(full_path, 'r', encoding='utf-8') as f:
                        changes = f.readlines()
                        for change in changes:
                            if change.startswith('+'):
                                dep_dict[name][5].append(change[1:].strip())
                            if change.startswith('-'):
                                dep_dict[name][6].append(change[1:].strip())
    return dep_dict


def analyse_package_xml(source_path):
    if source_path == '':
        return [None, [], [], [], None, None, None, None]
    xml_path = os.path.join(source_path, 'package.xml')
    tree = ET.parse(xml_path)
    root = tree.getroot()

    tag_order = [
        'name', 'depend', 'build_depend', 'build_export_depend', 'exec_depend',
        'test_depend', 'buildtool_depend', 'buildtool_export_depend', 'run_depend',
        'license', 'url', 'maintainer', 'description'
    ]

    tag_info = [None, [], [], [], None, None, None, None]

    first_maintainer_processed = False

    for child in root:
        tag = child.tag.split('}')[-1]
        attributes = child.attrib

        if tag in tag_order:
            if tag == 'name':
                tag_info[0] = child.text.strip().replace('_', '-')
            if tag in ['depend', 'build_export_depend', 'exec_depend', 'buildtool_export_depend', 'run_depend']:
                if 'condition' not in attributes \
                    or not (attributes['condition'] == "$ROS_VERSION == 1"
                            or attributes['condition'] == "$ROS_PYTHON_VERSION == 2"):
                    tag_info[1].append(child.text.strip().replace('_', '-'))
            if tag in ['depend', 'build_depend', 'buildtool_depend']:
                if 'condition' not in attributes \
                    or not (attributes['condition'] == "$ROS_VERSION == 1"
                            or attributes['condition'] == "$ROS_PYTHON_VERSION == 2"):
                    tag_info[2].append(child.text.strip().replace('_', '-'))
            if tag in ['test_depend']:
                if 'condition' not in attributes \
                    or not (attributes['condition'] == "$ROS_VERSION == 1"
                            or attributes['condition'] == "$ROS_PYTHON_VERSION == 2"):
                    tag_info[3].append(child.text.strip().replace('_', '-'))
            if tag == 'license':
                if tag_info[4]:
                    tag_info[4] = tag_info[4] + f" and {child.text.strip()}"
                else:
                    tag_info[4] = f"{child.text.strip()}"
            if tag == 'url':
                url_type = attributes.get('type')
                if url_type is None or url_type == "website":
                    tag_info[5] = child.text.strip()
            if tag == 'maintainer':
                if not first_maintainer_processed:
                    email = attributes.get('email')
                    maintainer_text = child.text.strip() if child.text else ""
                    if email:
                        tag_info[6] = f"{maintainer_text} {email.strip()}"
                    else:
                        tag_info[6] = maintainer_text
                    first_maintainer_processed = True
            if tag == 'description':
                tag_info[7] = child.text
    return tag_info


def get_version(filename):
    parts = filename.split('_')
    if len(parts) < 2:
        raise ValueError(f"Filename {filename} does not follow expected naming convention")
    version_part = parts[1]
    version = version_part.split('.orig.tar.gz')[0]
    return version


def have_c(directory):
    for entry in os.listdir(directory):
        full_path = os.path.join(directory, entry)
        if os.path.isdir(full_path) and entry == 'test':
            continue
        if os.path.isfile(full_path):
            if full_path.endswith(('.c', '.cpp')):
                return True
        elif os.path.isdir(full_path):
            if have_c(full_path):
                return True
    return False


def get_session():
    retry_strategy = Retry(
        total=5,  # 最大重试次数
        backoff_factor=1,  # 重试间隔时间的退避因子
        status_forcelist=[500, 502, 503, 504],  # 需要重试的 HTTP 状态码
        allowed_methods=["HEAD", "GET", "OPTIONS"],  # 允许重试的 HTTP 方法
        raise_on_status=False,  # 不立即因状态码异常而抛出错误
        respect_retry_after_header=False,
        connect=5,
        read=5
    )
    if not hasattr(thread_local, "session"):
        thread_local.session = requests.Session()
        retries = requests.adapters.HTTPAdapter(max_retries=retry_strategy)
        thread_local.session.mount('https://', retries)
        thread_local.session.mount('http://', retries)
    return thread_local.session


class Color:
    HEADER = '\033[95m'  # 标头（紫色）
    OK_BLUE = '\033[94m'
    OK_GREEN = '\033[92m'
    WARNING = '\033[93m'  # 警告
    ERROR = '\033[91m'  # 错误
    ENDC = '\033[0m'  # 重置
    BOLD = '\033[1m'  # 加粗
    UNDERLINE = '\033[4m'  # 下划线


class WorkspaceManager:

    def __init__(self, base_name='port_workspace'):
        self.base_name = base_name
        self.workspace_name = self.create_workspace()
        self.src_name = self.create_src()
        self.downloads = self.create_download()
        self.repo = self.create_repo()
        self.fix = self.create_fix()
        self.info_csv = self.create_info_csv()
        self.fix_csv = self.create_fix_csv()
        self.analyse_csv = self.create_analyse_csv()
        self.log = self.create_log()
        if not os.path.exists(os.path.join(self.fix, "cmake.spec")):
            shutil.copy(str(resources.files("ros_porting_tool_py").joinpath("cmake.spec")), self.fix)
        if not os.path.exists(os.path.join(self.fix, "python.spec")):
            shutil.copy(str(resources.files("ros_porting_tool_py").joinpath("python.spec")), self.fix)

    def create_workspace(self):
        workspace_name = self.base_name

        if not os.path.exists(workspace_name):
            os.makedirs(workspace_name)

        return workspace_name

    def create_src(self):
        src_name = os.path.join(self.workspace_name, 'src')

        if not os.path.exists(src_name):
            os.makedirs(src_name)

        return src_name

    def create_download(self):
        download_name = os.path.join(self.workspace_name, 'download')

        if not os.path.exists(download_name):
            os.makedirs(download_name)

        return download_name

    def create_repo(self):
        repo_name = os.path.join(self.workspace_name, 'repo')

        if not os.path.exists(repo_name):
            os.makedirs(repo_name)

        return repo_name

    def create_fix(self):
        fix_name = os.path.join(self.workspace_name, 'fix')

        if not os.path.exists(fix_name):
            os.makedirs(fix_name)

        return fix_name

    def create_info_csv(self):
        file_name = os.path.join(self.workspace_name, 'info.csv')
        if not os.path.exists(file_name):
            with open(file_name, mode='w', newline=''):
                pass
            return file_name
        else:
            return file_name

    def create_fix_csv(self):
        file_name = os.path.join(self.workspace_name, 'fix.csv')
        if not os.path.exists(file_name):
            with open(file_name, mode='w', newline=''):
                pass
            return file_name
        else:
            return file_name

    def create_analyse_csv(self):
        file_name = os.path.join(self.workspace_name, 'analyse.csv')
        if not os.path.exists(file_name):
            with open(file_name, mode='w', newline=''):
                pass
            return file_name
        else:
            return file_name

    def create_log(self):
        file_name = os.path.join(self.workspace_name, 'ros_port_tool.log')
        if not os.path.exists(file_name):
            with open(file_name, mode='w', newline=''):
                pass
            return file_name
        else:
            return file_name


class CSVFileHandler:
    def __init__(self, file_path):
        self.file_path = file_path

    def read(self, columns):

        with open(self.file_path, mode='r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            headers = next(reader)

            if len(columns) == 1:
                column_index = list(columns)[0]
                if column_index >= len(headers):
                    raise IndexError(f"列序号 {column_index} 超出范围")
                data = [row[column_index] for row in reader]
                return data

            else:
                result = {}
                for col_index in columns:
                    if col_index >= len(headers):
                        raise IndexError(f"列序号 {col_index} 超出范围")
                    header = headers[col_index]
                    result[header] = []

                for row in reader:
                    for col_index in columns:
                        result[headers[col_index]].append(row[col_index])

                return result

    def add_header(self, headers):
        with open(self.file_path, mode='r', newline='', encoding='utf-8') as csvfile:
            first_line = csvfile.readline()
            if not bool(first_line.strip()):
                with open(self.file_path, mode='w', newline='', encoding='utf-8') as csvfile_:
                    writer = csv.writer(csvfile_)
                    writer.writerow(headers)

    def write(self, data):
        max_length = max(len(lst) for lst in data.values())
        with open(self.file_path, mode='r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            existing_headers = next(reader)
            column_indices = {header: existing_headers.index(header) for header in data if header in existing_headers}
            rows = list(reader)
            for i in range(0, max_length):
                if i >= len(rows):
                    rows.append([])
                for key in data.keys():
                    while len(rows[i]) <= column_indices[key]:
                        rows[i].append('')
                    rows[i][column_indices[key]] = data[key][i]

        with open(self.file_path, mode='w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            rows.insert(0, existing_headers)
            writer.writerows(rows)

    def replace_row(self, replacements):
        rows = []
        with open(self.file_path, mode='r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            headers = next(reader)
            rows.append(headers)

            for row in reader:
                key_value = row[0]
                if key_value in replacements:
                    rows.append(replacements[key_value])
                else:
                    rows.append(row)

        with open(self.file_path, mode='w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(rows)

    def delete_row(self, keys_to_delete):
        rows = []
        with open(self.file_path, mode='r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            headers = next(reader)
            rows.append(headers)

            for row in reader:
                key_value = row[0]
                if key_value not in keys_to_delete:
                    rows.append(row)

        with open(self.file_path, mode='w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(rows)

    def write_row(self, data_dict):
        rows = []
        found_key = False

        with open(self.file_path, mode='r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            headers = next(reader)
            rows.append(headers)

            for row in reader:
                key_value = row[0]
                if key_value in data_dict:
                    new_row = [key_value] + data_dict[key_value]
                    rows.append(new_row)
                    found_key = True
                else:
                    rows.append(row)

        if not found_key:
            for key, values in data_dict.items():
                new_row = [key] + values
                rows.append(new_row)

        with open(self.file_path, mode='w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(rows)

    def read_all(self):
        data = []
        with open(self.file_path, mode='r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            next(reader)  # 跳过表头
            for row in reader:
                data.append(row)
        return data


class LinkFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            for attr in attrs:
                if attr[0] == 'href':
                    self.links.append(attr[1])


class PortManager:
    def __init__(self, src_path, repo_path, download_path, fix_path, info_csv_path, fix_csv_path, analyse_csv_path,
                 log_path, threads):
        self.src = src_path
        self.repo = repo_path
        self.download = download_path
        self.fix = fix_path
        self.info = info_csv_path
        self.fix_csv = fix_csv_path
        self.analyse = analyse_csv_path
        self.log = log_path
        self.yaml = str(resources.files("ros_porting_tool_py").joinpath("distribution.yaml"))
        self.threads = threads if threads < 10 else 10
        with resources.as_file(resources.files("ros_porting_tool_py").joinpath("source.json")) as json_path:
            with open(json_path, 'r', encoding='utf-8') as f:
                self.json = json.load(f)

    def analyse_yaml_to_info(self):
        if os.path.exists(self.yaml):
            with open(self.yaml) as file:
                data = yaml.safe_load(file)
        else:
            print()

        headers = [
            "package_name", "repo_name", "version",
            "release", "url", "new_version", "tar_name",
            "file_path", "spec_file", "debug_info", "xml"]

        info_csv = CSVFileHandler(self.info)
        info_csv.add_header(headers)

        info_dict = {
                     "package_name": [],
                     "repo_name": [],
                     "version": [],
                     "release": [],
                     "url": []
                     }

        for repo, info in data.get('repositories', {}).items():
            source = info.get('source', {})
            release = info.get('release', {})
            packages = release.get('packages') or [repo]
            url = source.get('url') or release.get('url', '')
            repo_name = url.replace('.git', '').split('/')[-1].replace('_', '-')
            version = source.get('version', '')
            release_version = release.get('version', '')
            for pkg in packages:
                info_dict["package_name"].append(pkg.replace('_', '-'))
                info_dict["repo_name"].append(repo_name)
                info_dict["version"].append(version)
                info_dict["release"].append(release_version)
                info_dict["url"].append(url)

        info_csv.write(info_dict)

    def find_download_and_download(self, url):
        if not url:
            print(Color.ERROR + "无链接输入" + Color.ENDC)
            return [None, None]
        try:
            session = get_session()
            response = session.get(url, verify=False, timeout=5)
            if response.status_code != 200:
                print(Color.ERROR + f"链接{url}对应的包不能访问！" + Color.ENDC)
                return ["url", url]
            content = response.content.decode('utf-8')

            parser_ = LinkFinder()
            parser_.feed(content)

            pattern = re.compile(r'^ros-humble.*\.orig\.tar\.gz$')
            matches = [link for link in parser_.links if pattern.match(link)]
            if matches:
                file_path = os.path.join(self.download, matches[0])
                try:
                    if os.path.exists(file_path):
                        print(f"{Color.WARNING}File {matches[0]} exists{Color.ENDC}")
                        return [True, matches[0]]
                    url = url + '/' + matches[0]
                    response = session.get(url, verify=False, timeout=5, stream=True)
                    with open(file_path, 'wb') as file:
                        for chunk in response.iter_content(chunk_size=8192):
                            if chunk:
                                file.write(chunk)
                    print(f"{Color.OK_GREEN}Downloaded {matches[0]}{Color.ENDC}")
                    return [True, matches[0]]
                except Exception as e:
                    error_msg = str(e)
                    print(f"{Color.ERROR}Error {matches[0]}: {error_msg}{Color.ENDC}")
                    return ["download", url]
            else:
                print(Color.ERROR + f"无法找到压缩包链接" + Color.ENDC)
                return ["tar", url]
        except Exception as e:
            error_msg = str(e)
            print(f"{Color.ERROR}Error :{error_msg} {Color.ENDC}")
            return [None, None]

    def download_all_file(self):
        info = CSVFileHandler(self.info)
        pkg_names = info.read([0])
        urls = []
        for pkg_name in pkg_names:
            urls.append(f"https://packages.ros.org/ros2/ubuntu/pool/main/r/ros-humble-{pkg_name}")
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            res_ = [executor.submit(self.find_download_and_download, url) for url in urls]
            res_list = [match.result() for match in res_]
        csv_ = []
        for info in res_list:
            if not info[0]:
                csv_.append(info[1])
            elif info[0] == 'url':
                csv_.append(None)
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                log_entry = (
                    f"{timestamp} [ERROR] [download_all_file] "
                    f"无法访问 - 错误详情: {info[1]}\n"
                )
                with open(self.log, 'a') as file:
                    file.write(log_entry)

            elif info[0] == 'download':
                csv_.append(None)
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                log_entry = (
                    f"{timestamp} [ERROR] [download_all_file] "
                    f"无法下载 - 错误详情: {info[1]}\n"
                )
                with open(self.log, 'a') as file:
                    file.write(log_entry)

            elif info[0] == 'tar':
                csv_.append(None)
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                log_entry = (
                    f"{timestamp} [ERROR] [download_all_file] "
                    f"寻找不到压缩包下载连接 - 错误详情: {info[1]}\n"
                )
                with open(self.log, 'a') as file:
                    file.write(log_entry)

            elif info[0]:
                csv_.append(info[1])
        tar_name = {'tar_name': csv_}
        info = CSVFileHandler(self.info)
        info.write(tar_name)

    def tar_file_and_analyse_folder(self, tar_name, pyspec):
        if tar_name == '':
            return None
        try:
            tar_path = os.path.join(self.download, tar_name)
            with tarfile.open(tar_path, 'r:gz') as tar:
                folder_name = tar_name.split('.orig.tar.gz')[0].replace('_', '-')
                folder_path = os.path.join(self.src, folder_name)
                if not os.path.exists(folder_path):
                    tar.extractall(path=self.src)
                    print(f"成功解压缩 {tar_path} 到 {folder_path}。")
                else:
                    print(f"{folder_path}存在同名目录，请手动确认其是否是解压后文件夹。")
        except tarfile.TarError as e:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_entry = (
                f"{timestamp} [ERROR] [tar_file_and_analyse_folder] "
                f"解压错误 - 错误详情: {e}\n"
            )
            with open(self.log, 'a') as file:
                file.write(log_entry)
            print(f"错误: 解压缩文件时发生 Tar 错误: {e}")
            return None
        except Exception as e:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_entry = (
                f"{timestamp} [ERROR] [tar_file_and_analyse_folder] "
                f"解压错误 - 错误详情: {e}\n"
            )
            with open(self.log, 'a') as file:
                file.write(log_entry)
            print(f"错误: 发生了一个未知错误: {e}")
            return None
        pkg_name = tar_name.split('_')[0].replace('ros-humble-', '')
        xml_flag = os.path.exists(os.path.join(folder_path, 'package.xml'))
        cmake_flag = os.path.exists(os.path.join(folder_path, 'CMakeLists.txt')) and pkg_name not in pyspec
        version = get_version(tar_name)
        debug_flag = (pkg_name not in self.json["debug_info"]) and have_c(folder_path)
        return xml_flag, cmake_flag, version, debug_flag, folder_path

    def process_folders(self):
        info = CSVFileHandler(self.info)
        tar_names = info.read([6])
        pyspec = self.json["pyspec"]
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            res_ = [executor.submit(self.tar_file_and_analyse_folder, tar_name, pyspec) for tar_name in tar_names]
            res_list = [match.result() for match in res_]
        folder_info = {
                      'xml': [],
                      'new_version': [],
                      'file_path': [],
                      'spec_file': [],
                      'debug_info': []
                      }
        for res in res_list:
            if not res:
                folder_info['xml'].append('')
                folder_info['spec_file'].append('')
                folder_info['new_version'].append('')
                folder_info['debug_info'].append('')
                folder_info['file_path'].append('')
            else:
                if res[0]:
                    folder_info['xml'] .append('1')
                else:
                    folder_info['xml'] .append('0')
                if res[1]:
                    folder_info['spec_file'].append('1')
                else:
                    folder_info['spec_file'].append('0')
                if res[3]:
                    folder_info['debug_info'].append('1')
                else:
                    folder_info['debug_info'].append('0')
                folder_info['new_version'].append(res[2])
                folder_info['file_path'].append(res[4])
        info.write(folder_info)

    def process_files(self):
        analyse = CSVFileHandler(self.analyse)
        header = ['name', 'Requires', 'BuildRequires', 'test-BuildRequires', 'license', 'url',
                  'maintainer', 'description']
        analyse.add_header(header)
        info = CSVFileHandler(self.info)
        source_paths = info.read([7])
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            res_ = [executor.submit(analyse_package_xml, source_path) for source_path in source_paths]
            res_list = [match.result() for match in res_]
        analyse_dict = {'name': [depend[0] for depend in res_list],
                        'Requires': [" ".join(depend[1]) for depend in res_list],
                        'BuildRequires': [" ".join(depend[2]) for depend in res_list],
                        'test-BuildRequires': [" ".join(depend[3]) for depend in res_list],
                        'license': [depend[4] for depend in res_list],
                        'url': [depend[5] for depend in res_list],
                        'maintainer': [depend[6] for depend in res_list],
                        'description': [depend[7] for depend in res_list]
                        }
        analyse.write(analyse_dict)

    def import_extra_dependencies(self):
        fix_csv = CSVFileHandler(self.fix_csv)
        header = ['name', 'add_build_requires', 'sub_build_requires', 'provides', 'add_requires',
                  'sub_requires', 'add_test-build_requires', 'sub_test-build_requires']
        fix_csv.add_header(headers=header)
        fix_dict = analyse_extra_dependencies(self.fix)
        for name in fix_dict.keys():
            for i in range(0, 7):
                if len(fix_dict[name][i]) == 0:
                    fix_dict[name][i] = None
                elif len(fix_dict[name][i]) == 1:
                    fix_dict[name][i] = fix_dict[name][i][0]
                elif len(fix_dict[name][i]) > 1:
                    if i == 2:
                        continue
                    else:
                        temp_str = " ".join(fix_dict[name][i])
                        fix_dict[name][i] = temp_str
        fix_csv.write_row(fix_dict)

    def get_spec(self, info_csv, fix_csv, analyse_csv, package_list, path, package_rename):
        if not info_csv or info_csv[7] == '':
            return
        keyword_value_mapping = {
            "ROS_PACKAGE_NO_DEBUGINFO": "",
            "ROS_PACKAGE_NAME": info_csv[0],
            "ROS_PACKAGE_VERSION": "",
            "ROS_PACKAGE_SUMMARY": "",
            "ROS_PACKAGE_URL": "",
            "ROS_PACKAGE_LICENSE": "",
            "ROS_SOURCE_FIX": "",
            "ROS_PACKAGE_REQUIRES": "",
            "ROS_PACKAGE_BUILDREQUIRES": "",
            "ROS_TEST_BUILDREQUIRES": "",
            "ROS_PROVIDES_FIX": "",
            "ROS_PACKAGE_DESCRIPTION": "",
            "ROS_PACKAGE_RELEASE": "",
            "ROS_PREP_FIX": "",
            "ROS_ALL_FIX_REQUIRES": "",
            "ROS_PACKAGE_CHANGELOG": ""
        }
        analyse = fix = None
        for row in fix_csv:
            if row[0] == info_csv[0]:
                fix = row
                break
        for row in analyse_csv:
            if row[0] == info_csv[0]:
                analyse = row
                break
        keyword_value_mapping["ROS_PACKAGE_RELEASE"] = '1'
        if info_csv[9] == '0':
            keyword_value_mapping["ROS_PACKAGE_NO_DEBUGINFO"] = "%global debug_package %{nil}"
        keyword_value_mapping["ROS_PACKAGE_VERSION"] = info_csv[5]
        if len(analyse[7].splitlines()) > 1:
            keyword_value_mapping["ROS_PACKAGE_SUMMARY"] = "ROS " + info_csv[0] + " package"
            keyword_value_mapping["ROS_PACKAGE_DESCRIPTION"] = analyse[7].strip()
        else:
            keyword_value_mapping["ROS_PACKAGE_SUMMARY"] = analyse[7].strip()
            keyword_value_mapping["ROS_PACKAGE_DESCRIPTION"] = analyse[7].strip()
        keyword_value_mapping["ROS_PACKAGE_URL"] = analyse[5]
        keyword_value_mapping["ROS_PACKAGE_LICENSE"] = analyse[4]
        keyword_value_mapping["ROS_PROVIDES_FIX"] = '' if fix is None else fix[3]
        keyword_value_mapping["ROS_PACKAGE_CHANGELOG"] = datetime.now().strftime("%a %b %d %Y") + ' ' \
            + analyse[6].replace('\n', '') + ' - ' + info_csv[5] + '-1'
        if os.path.exists(path + r'\source.fix'):
            with open(path + r'\source.fix', 'r', encoding='utf-8') as file:
                content = file.read()
                keyword_value_mapping["ROS_SOURCE_FIX"] = content
        if os.path.exists(path + r'\prep.fix'):
            with open(path + r'\prep.fix', 'r', encoding='utf-8') as file:
                content = file.read()
                keyword_value_mapping["ROS_PREP_FIX"] = content

        requires_add = set(fix[4].split()) if fix else set()
        requires_sub = set(fix[5].split()) if fix else set()
        requires = set(analyse[1].split())
        requires.update(requires_add)
        requires.difference_update(requires_sub)
        final_requires = {package_rename.get(item, item) for item in requires}
        for item in final_requires:
            if item in package_list:
                keyword_value_mapping["ROS_PACKAGE_REQUIRES"] = keyword_value_mapping["ROS_PACKAGE_REQUIRES"] \
                                                                + "Requires: ros-%{ros_distro}-" + item + '\n'
            else:
                keyword_value_mapping["ROS_PACKAGE_REQUIRES"] = keyword_value_mapping["ROS_PACKAGE_REQUIRES"] \
                                                                + "Requires: " + item + '\n'
        build_requires_add = set(fix[1].split()) if fix else set()
        build_requires_sub = set(fix[2].split()) if fix else set()
        build_requires = set(analyse[2].split())
        build_requires.update(build_requires_add)
        build_requires.difference_update(build_requires_sub)
        final_build_requires = {package_rename.get(item, item) for item in build_requires}
        for item in final_build_requires:
            if item in package_list:
                keyword_value_mapping["ROS_PACKAGE_BUILDREQUIRES"] = keyword_value_mapping["ROS_PACKAGE_BUILDREQUIRES"]\
                                                                     + "BuildRequires: ros-%{ros_distro}-" + item + '\n'
            else:
                keyword_value_mapping["ROS_PACKAGE_BUILDREQUIRES"] = keyword_value_mapping["ROS_PACKAGE_BUILDREQUIRES"]\
                                                                     + "BuildRequires: " + item + '\n'

        test_requires_add = set(fix[6].split()) if fix else set()
        test_requires_sub = set(fix[7].split()) if fix else set()
        test_requires = set(analyse[3].split())
        test_requires.update(test_requires_add)
        test_requires.difference_update(test_requires_sub)
        final_test_requires = {package_rename.get(item, item) for item in test_requires}
        for item in final_test_requires:
            if item in package_list:
                keyword_value_mapping["ROS_TEST_BUILDREQUIRES"] = keyword_value_mapping["ROS_TEST_BUILDREQUIRES"] \
                                                                  + "BuildRequires: ros-%{ros_distro}-" + item + '\n'
            else:
                keyword_value_mapping["ROS_TEST_BUILDREQUIRES"] = keyword_value_mapping["ROS_TEST_BUILDREQUIRES"] \
                                                                  + "BuildRequires: " + item + '\n'
        output_path = os.path.join(self.repo, info_csv[0])
        cmake_path = os.path.join(self.fix, "cmake.spec")
        python_path = os.path.join(self.fix, "python.spec")
        if info_csv[8] == '1':
            replace_keywords_and_save_to_new_file(cmake_path, output_path, keyword_value_mapping)
        else:
            replace_keywords_and_save_to_new_file(python_path, output_path, keyword_value_mapping)

    def spec_all(self):
        info = CSVFileHandler(self.info)
        info_list = info.read_all()
        pkg_list = info.read([0])
        analyse = CSVFileHandler(self.analyse)
        analyse_list = analyse.read_all()
        fix = CSVFileHandler(self.fix_csv)
        fix_list = fix.read_all()
        for info_row in info_list:
            self.get_spec(info_row, fix_list, analyse_list, pkg_list,
                          os.path.join(self.fix, info_row[0]), self.json["pkg_rename"])

    def move_all(self):
        info = CSVFileHandler(self.info)
        info_list = info.read([0, 6])
        for i in range(len(info_list["package_name"])):
            if info_list["tar_name"] != '':
                move(os.path.join(self.download, info_list["tar_name"][i]),
                     os.path.join(self.repo, info_list["package_name"][i]),
                     os.path.join(self.fix, info_list["package_name"][i]))


def setup_parser():
    parser = argparse.ArgumentParser(description="程序描述")
    parser.add_argument(
        "-thread",
        type=int,
        default=10,
        help="线程数，默认为10"
    )

    parser.add_argument(
        "--init",
        action="store_true",
        help="Run initialization logic."
    )

    return parser


def main():
    parser = setup_parser()
    args = parser.parse_args()
    if args.init:
        work_base = WorkspaceManager()
        if judge_init():
            print(Color.OK_GREEN + "初始化工作目录成功" + Color.ENDC)
        else:
            print(Color.ERROR + "初始化工作目录失败，检查后重新初始化" + Color.ENDC)
    elif args.thread > 0:  # 确保线程数大于0
        if judge_init():
            work_base = WorkspaceManager()
            port = PortManager(
                work_base.src_name,
                work_base.repo,
                work_base.downloads,
                work_base.fix,
                work_base.info_csv,
                work_base.fix_csv,
                work_base.analyse_csv,
                work_base.log,
                args.thread
            )
            port.analyse_yaml_to_info()
            port.download_all_file()
            port.process_folders()
            port.process_files()
            port.import_extra_dependencies()
            port.spec_all()
            port.move_all()
        else:
            print(Color.ERROR + "初始化工作目录失败，检查后重新初始化" + Color.ENDC)
    else:
        print("请提供有效的参数：--init 或 -thread <number>")


if __name__ == "__main__":
    main()
