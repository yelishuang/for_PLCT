from setuptools import setup, find_packages

setup(
    name="ros_porting_tool_py",  # 包名
    version="0.1.0",             # 版本号
    packages=find_packages(),    # 自动查找所有包
    install_requires=[
        "certifi>=2025.1.31",
        "charset-normalizer>=3.4.1",
        "idna>=3.10",
        "PyYAML>=6.0.2",
        "requests>=2.32.3",
        "urllib3>=2.3.0",
    ],
    entry_points={
        "console_scripts": [
            "ros-porting-tool-py=ros_porting_tool_py.main:main",  # 命令行工具
        ],
    },
    include_package_data=True,  # 确保包含非 Python 文件（如配置文件）
    package_data={
        "ros_porting_tool_py": ["*.yaml", "*.json", "*.ini", ".spec"],  # 包含特定类型的文件
    },
)