^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tf2_eigen_kdl
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.25.18 (2025-11-28)
--------------------

0.25.17 (2025-10-17)
--------------------

0.25.16 (2025-07-25)
--------------------

0.25.15 (2025-07-16)
--------------------

0.25.14 (2025-05-14)
--------------------

0.25.13 (2025-05-14)
--------------------

0.25.12 (2025-01-17)
--------------------

0.25.11 (2025-01-14)
--------------------

0.25.10 (2024-12-19)
--------------------
* Humble "Backport" of `#720 <https://github.com/ros2/geometry2/issues/720>`_ (`#722 <https://github.com/ros2/geometry2/issues/722>`_)
* Contributors: Lucas Wendland

0.25.9 (2024-11-20)
-------------------

0.25.8 (2024-08-29)
-------------------

0.25.7 (2024-05-29)
-------------------

0.25.6 (2024-02-16)
-------------------

0.25.5 (2023-11-13)
-------------------

0.25.4 (2023-09-19)
-------------------

0.25.3 (2023-07-17)
-------------------

0.25.2 (2023-01-10)
-------------------

0.25.1 (2022-08-05)
-------------------
* Use orocos_kdl_vendor and orocos-kdl target (`#548 <https://github.com/ros2/geometry2/issues/548>`_)
* Contributors: Scott K Logan

0.25.0 (2022-04-05)
-------------------
* Fix more instances of Eigen problems on RHEL. (`#515 <https://github.com/ros2/geometry2/issues/515>`_)
* Depend on orocos_kdl_vendor  (`#473 <https://github.com/ros2/geometry2/issues/473>`_)
* Install includes to include/${PROJECT_NAME} and use modern CMake (`#493 <https://github.com/ros2/geometry2/issues/493>`_)
* Contributors: Chris Lalancette, Jacob Perron, Shane Loretz

0.24.0 (2022-03-31)
-------------------

0.23.0 (2022-03-28)
-------------------

0.22.0 (2022-03-01)
-------------------

0.21.0 (2022-01-14)
-------------------
* Fix cpplint errors (`#497 <https://github.com/ros2/geometry2/issues/497>`_)
* Contributors: Jacob Perron

0.20.0 (2021-12-17)
-------------------

0.19.0 (2021-10-15)
-------------------

0.18.0 (2021-06-01)
-------------------

0.17.1 (2021-04-06)
-------------------

0.17.0 (2021-03-19)
-------------------

0.16.0 (2021-01-25)
-------------------

0.15.1 (2020-12-08)
-------------------
* fix order of find eigen3_cmake_module & find eigen3 (`#344 <https://github.com/ros2/geometry2/issues/344>`_)
* Contributors: Ahmed Sobhy

0.15.0 (2020-11-02)
-------------------
* Update package.xml (`#333 <https://github.com/ros2/geometry2/issues/333>`_)
* Port eigen_kdl.h/cpp to ROS2 (`#311 <https://github.com/ros2/geometry2/issues/311>`_)
* Contributors: Jafar Abdi
