^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package examples_tf2_py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.25.18 (2025-11-28)
--------------------

0.25.17 (2025-10-17)
--------------------
* Fix Setuptools deprecations (`#809 <https://github.com/ros2/geometry2/issues/809>`_) (`#831 <https://github.com/ros2/geometry2/issues/831>`_)
* Contributors: mergify[bot]

0.25.16 (2025-07-25)
--------------------

0.25.15 (2025-07-16)
--------------------

0.25.14 (2025-05-14)
--------------------

0.25.13 (2025-05-14)
--------------------

0.25.12 (2025-01-17)
--------------------

0.25.11 (2025-01-14)
--------------------

0.25.10 (2024-12-19)
--------------------

0.25.9 (2024-11-20)
-------------------

0.25.8 (2024-08-29)
-------------------

0.25.7 (2024-05-29)
-------------------

0.25.6 (2024-02-16)
-------------------

0.25.5 (2023-11-13)
-------------------

0.25.4 (2023-09-19)
-------------------

0.25.3 (2023-07-17)
-------------------

0.25.2 (2023-01-10)
-------------------

0.25.1 (2022-08-05)
-------------------

0.25.0 (2022-04-05)
-------------------

0.24.0 (2022-03-31)
-------------------

0.23.0 (2022-03-28)
-------------------

0.22.0 (2022-03-01)
-------------------

0.21.0 (2022-01-14)
-------------------

0.20.0 (2021-12-17)
-------------------
* Update maintainers to Alejandro Hernandez Cordero and Chris Lalancette (`#481 <https://github.com/ros2/geometry2/issues/481>`_)
* Contributors: Audrow Nash

0.19.0 (2021-10-15)
-------------------

0.18.0 (2021-06-01)
-------------------
* Use underscores instead of dashes in setup.cfg. (`#403 <https://github.com/ros2/geometry2/issues/403>`_)
* Contributors: Chris Lalancette

0.17.1 (2021-04-06)
-------------------

0.17.0 (2021-03-19)
-------------------

0.16.0 (2021-01-25)
-------------------

0.15.1 (2020-12-08)
-------------------

0.15.0 (2020-11-02)
-------------------
* Update maintainers of the ros2/geometry2 fork. (`#328 <https://github.com/ros2/geometry2/issues/328>`_)
* Contributors: Chris Lalancette

0.14.1 (2020-09-21)
-------------------

0.14.0 (2020-08-14)
-------------------
* Add pytest.ini so local tests don't display warning (`#276 <https://github.com/ros2/geometry2/issues/276>`_)
* Split tf2_ros in tf2_ros and tf2_ros_py (`#210 <https://github.com/ros2/geometry2/issues/210>`_)
* Contributors: Alejandro Hernández Cordero, Chris Lalancette

0.13.4 (2020-06-03)
-------------------

0.13.3 (2020-05-26)
-------------------

0.13.2 (2020-05-18)
-------------------

0.13.1 (2020-05-08)
-------------------

0.13.0 (2020-04-30)
-------------------
* more verbose test_flake8 error messages (same as `ros2/launch_ros#135 <https://github.com/ros2/launch_ros/issues/135>`_)
* Contributors: Dirk Thomas

0.12.4 (2019-11-19)
-------------------
* Add Python examples for tf2_ros (`#161 <https://github.com/ros2/geometry2/issues/161>`_)
