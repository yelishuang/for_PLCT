int main ()
{
   a    = 5;
   bbbb = 6.0;
   int a      = 5;
   float bbbb = 6.0;

   bbbb = 1.0
}
