void Func1()
{
	OtherFunc( 5, b );
}

void Func2()
{
	Func3( p1,   p2,   p3 );
	Func3( p111, p222, p333 );
}
