void main()
{
	if (true) return;

	mInitialized = true;
	return 0;
}
