void
foo(map< int, int >& aaa,
    int              bbb)
{
}
