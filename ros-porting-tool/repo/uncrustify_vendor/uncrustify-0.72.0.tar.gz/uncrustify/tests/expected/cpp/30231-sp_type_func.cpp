int foo1()
{
}

int* foo2()
{
}

int& foo3()
{
}
