void foo()
{
	bar<T>();
	bar<T> (a);
}
