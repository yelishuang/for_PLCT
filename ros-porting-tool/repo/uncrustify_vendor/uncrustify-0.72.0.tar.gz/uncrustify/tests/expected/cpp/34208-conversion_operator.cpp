template< class T >
operator T*() const
{
	return 0;
}