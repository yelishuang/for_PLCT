void A
::f()
{
}
