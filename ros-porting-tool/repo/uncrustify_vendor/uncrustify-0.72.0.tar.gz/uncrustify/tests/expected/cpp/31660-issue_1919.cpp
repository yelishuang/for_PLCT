void foo()
{
	int a;
	vector<unsigned> b;
	long c;
	decltype(a) d;
}

void bar()
{
	int a;
	std::vector<unsigned> b;
	long c;
	decltype(a) d;
}
