{
	a = ( int ) 5.6;
	b = int( 5.6 );
}
