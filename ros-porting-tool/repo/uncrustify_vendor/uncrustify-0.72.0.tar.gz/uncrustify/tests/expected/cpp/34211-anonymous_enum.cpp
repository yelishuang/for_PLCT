enum {
  E11 = 0,
  E12 = 1,
  E13 = 2
};

enum Enum1 {
  E21 = 0,
  E22 = 1,
  E23 = 2
};

enum Enum2 : int {
  E31 = 0,
  E32 = 1,
  E33 = 2
};

enum Enum3
: int {
  E41 = 0,
  E42 = 1,
  E43 = 2
};

enum : int {
  E51 = 0,
  E52 = 1,
  E53 = 2
};

enum
: int {
  E61 = 0,
  E62 = 1,
  E63 = 2
};