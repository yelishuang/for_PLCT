void HouseNumberData(Translation const & trans  = Translation { },
                     Orientation const & orient = Orientation { },
                     CategoryIds const & cats   = CategoryIds(),
                     std::string const & txt    = std::string { },
                     bool active = false);

void HouseNumberData(Translation const & trans______________,
                     Orientation const & orient______________________,
                     CategoryIds const & cats_____________________,
                     std::string const & txt___________________,
                     bool active_________);

