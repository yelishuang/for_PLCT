class ATL_NO_VTABLE CProxy :
        public ATL::CComCoClass<CProxy, &CLSID_Proxy>
{
}
