int fail = doSomething(
  argument
).doNotIndentMe();
