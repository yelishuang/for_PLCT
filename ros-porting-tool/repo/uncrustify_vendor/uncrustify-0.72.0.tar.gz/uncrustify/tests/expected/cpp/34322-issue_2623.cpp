void child() {
	static_cast<id<Mountable>> ( object);
}

assert(x<0 && y>=3);
assert(y <0&&z> 2);
assert(a>>1);

std::unique_ptr<Interface<T>> GetProjectionAdapter(const std::string& model_name);

auto c = a< b>>c;
auto c = a << b >>c;

if (Something<a> == c) {
}

if (id<Something<a>> == c) {
}

const std::vector<Eigen::Matrix<T, A, B>> & P_c;

const unsigned int wl = w>> lvl;

using Poly = Model<P, Poly<Dx,Dy, Dz>>;

void Compute(
	Image<E::Matrix<SType, Dim,Int>> const& src,
	Image<E::Matrix<TType,Dim, std::string>>& dst);

Opt<std::vector <std::unordered_set<FrameId>>> partition;
