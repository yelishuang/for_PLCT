VIEW_CONTROLLER_MACRO(ThreadButton)
UIViewController *MSGCreate(MBAMailbox *mailbox, NSNumber *threadKey);


NS_SWIFT_NAME(Create(String))
Controller *create(NSString *str);


MACRO_FUNCTION
Object *create( NSString *str, NSDictionary<NSString *, NSArray *> *data, string **str)
{
	return nullptr;
}
