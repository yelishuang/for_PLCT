do {
        xxx = _error;
} while (0)
