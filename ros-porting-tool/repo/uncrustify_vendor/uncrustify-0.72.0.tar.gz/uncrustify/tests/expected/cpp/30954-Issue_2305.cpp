template<class T>
class Foo<T>::Bar
{
    void
    Bar(int iii)
        : iii(0)
    {
    }
};
