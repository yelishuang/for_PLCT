namespace hw { namespace stm32 {

class RTC {
};

}} // namespace hw::stm32
