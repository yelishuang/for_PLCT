class MyClass
{
public:
::some::name* foo;
};