class Test {
public:
void funca()
{
	static_cast<A>(funcb(static_cast<B>(
				     info)));
}
};
