void Foo1(BarType & x, void BarFunc());

void Bar()
{
    void BarFunc2(BarType & x);
}
