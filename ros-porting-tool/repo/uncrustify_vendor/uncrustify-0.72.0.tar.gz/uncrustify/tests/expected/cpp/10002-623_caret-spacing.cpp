Foo^ foo = dynamic_cast<Bar^>(bar);
Foo* foo = dynamic_cast<Bar*>(bar);
x = a ^ b;
