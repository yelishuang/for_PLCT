Foo()
noexcept()
{}
