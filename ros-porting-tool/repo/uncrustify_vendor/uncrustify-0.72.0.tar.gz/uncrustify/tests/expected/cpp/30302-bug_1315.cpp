dookie::wookie << "asd"
               << "bag"
               << "sag";

typedef enum
{
        A= 0,
        B= 1 << 0,
        C= 1 << 1
};

enum
{
        A= 0,
        B= 1 << 0,
        C= 1 << 1
};
