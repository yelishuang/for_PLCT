void f();

namespace A {

void f2();

namespace S {

void f3();

class C
{
};

void f4();

} // namespace S

void f5();

} // namespace A

void f6();

namespace E
{

void f7();

class D
{
};

;
void f9();

}

;
void f10();
