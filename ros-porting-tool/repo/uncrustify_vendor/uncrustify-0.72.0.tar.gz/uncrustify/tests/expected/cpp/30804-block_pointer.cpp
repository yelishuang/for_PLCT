__block __weak void (^weak_recurseTreeNodes)(int a);
void (^strong_recurseTreeNodes)(int a) = ^(int a) {
};

the result file:
Foo^ foo = dynamic_cast<Bar^>(bar);
Foo* foo = dynamic_cast<Bar*>(bar);
x = a ^ b;
int main(Platform::Array<Platform::String^>^ /*args*/)
{
}

void (*fun_ptr)(int) = &fun;

typedef void (*foo)(void);
void (*foo)(void);
