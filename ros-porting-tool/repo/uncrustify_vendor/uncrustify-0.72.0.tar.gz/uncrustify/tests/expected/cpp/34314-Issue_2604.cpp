void funcPROTO( int parameter1, int parameter2, int parameter3, int parameter4, int parameter5, int parameter6, int parameter7);

void funcDEF( int parameter1, int parameter2, int parameter3, int parameter4, int parameter5, int parameter6, int parameter7)
{
	funcCALL( parameter1, parameter2, parameter3, parameter4, parameter5, parameter6, parameter7 );
}
