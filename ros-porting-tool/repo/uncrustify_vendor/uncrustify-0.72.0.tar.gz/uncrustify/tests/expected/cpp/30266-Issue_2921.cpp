namespace Namespace1
{
namespace Namespace2
{
namespace Namespace3
{
namespace Namespace4
{
namespace Namespace5
{
namespace Namespace6
{
namespace Namespace7
{
namespace Namespace8
{
class ClassName
{
public:
ClassName(int a,
          int b);

private:
int a;
int b;
};
}
}
}
}
}
}
}
}
