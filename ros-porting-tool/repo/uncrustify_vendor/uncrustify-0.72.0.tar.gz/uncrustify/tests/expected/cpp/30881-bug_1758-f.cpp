int main()
{

	for(int f=0; f < 1; f++)
		auto a = int{1};

	return 0;
}
