class MyClass
{
public:
   virtual void f1ooooooooooooooo(const int bar);
   virtual void f2oooooooooooooooo(const int bar);
   virtual void f3ooooooooooooooooo(
      const int bar);
   virtual void f4oooooooooooooooooo(
      const int bar);
   virtual void f5ooooooooooooooooooo(
      const int bar);
};

virtual void f1oooooooooooooooooo(const int bar);
virtual void f2ooooooooooooooooooo(const int bar);
virtual void f3oooooooooooooooooooo(
   const int bar);
virtual void f4ooooooooooooooooooooo(
   const int bar);
virtual void f5oooooooooooooooooooooo(
   const int bar);

void foo()
{
   std::string s1 = "f1oooooooooooooooooooooooo";
   std::string s2 = "f2ooooooooooooooooooooooooo";
   std::string s3 =
         "f3oooooooooooooooooooooooooo";
   std::string s4 =
         "f4ooooooooooooooooooooooooooo";
   std::string s5 =
         "f5oooooooooooooooooooooooooooo";
}
