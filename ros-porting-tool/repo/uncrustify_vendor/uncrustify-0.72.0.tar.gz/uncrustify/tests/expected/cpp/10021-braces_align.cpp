char *array_assign[2][4] =
{
    {
        // foo
        {"foo"},
        {"foo@1"}, {"foo@2"}, {"foo@3"}
    },
    {
        // bar
        {"bar"},
        {"bar@1"}, {"bar@2"}, {"bar@3"}
    }
};
