int          x1      = 0;
foobar       long_x2 = 0;
foo<int>     x3      = 0;
int          x4[]    = {1, 2, 3};
decltype(x1) x5      = 0;
