auto p = std::make_pair(r * cos(a), r * sin(a));
