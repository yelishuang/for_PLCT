switch (a)
{
  case 0:
    // code
  break;
}
