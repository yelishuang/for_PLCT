template< >
struct Bar< false >: Foo
{
};
