﻿// the file is UTF-8 Unicode (with BOM)
// Euro character
€;
