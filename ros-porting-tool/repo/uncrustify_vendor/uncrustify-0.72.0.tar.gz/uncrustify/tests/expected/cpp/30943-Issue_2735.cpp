void func(int a){
    switch (a)
    {
        case 1:
            ;
        break;

        case 2:
            ;
        break;

        case 3:
        {
            int b = 3;
        }
        break;

        case 4:
        {
            float f = 4.0;
        }
        break;
    }
}
