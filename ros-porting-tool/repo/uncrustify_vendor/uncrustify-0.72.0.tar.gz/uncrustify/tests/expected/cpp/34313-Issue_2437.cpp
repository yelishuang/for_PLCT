void timer_cb1(struct timer_node *n);
typedef void timer_cb (struct timer_node *n);
