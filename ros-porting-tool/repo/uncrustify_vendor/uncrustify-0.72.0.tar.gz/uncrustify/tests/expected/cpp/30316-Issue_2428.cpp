void test()
{
        int{ 0 };
        int abcdef{ 0 };
}
