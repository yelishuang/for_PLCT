void Foo(int value)
{
    m_Foo[0].prop
        = m_Foo[1].prop
            = m_Foo[2].prop
                = m_Foo[3].prop
                    = m_Foo[4].prop
                        = m_Foo[5].prop = value;
}
