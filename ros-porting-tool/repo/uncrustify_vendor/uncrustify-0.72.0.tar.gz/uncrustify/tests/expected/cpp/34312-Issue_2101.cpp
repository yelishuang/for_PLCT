void Test()
{
    aaaaaa = condition ? FunctionWithVeryLongName( andWithVeryLongArgumentsToo1, andWithVeryLongArgumentsToo2 )
                       : FunctionWithVeryLongName( andWithVeryLongArgumentsToo2, andWithVeryLongArgumentsToo1 );
}
