
{
	/*
	 * test for new lines, everywhere
	 */
}
