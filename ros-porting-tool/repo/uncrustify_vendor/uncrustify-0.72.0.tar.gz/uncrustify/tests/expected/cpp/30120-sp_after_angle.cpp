template< typename T >
struct foo {};

Q_DECLARE_METATYPE(foo < int > )

int bar(foo < int > );
