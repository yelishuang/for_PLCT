/**
 * @file kw_subst.cpp
 * Description
 *
 * $Id$
 */
#include <string>

/**
 * CLASS:  CFoo
 * TODO: DESCRIPTION
 */
class CFoo
{
int foo1(int arg);
int foo2();
/**
 * CLASS:  CFoo
 * METHOD: foo3
 * TODO: DESCRIPTION
 * @param ch TODO
 * @param xx TODO
 * @return TODO
 */
int foo3(char ch, int xx)
{
}
};

/**
 * CLASS:  CFoo
 * METHOD: foo1
 * TODO: DESCRIPTION
 * @param arg TODO
 * @param arg2 TODO
 * @return TODO
 */
int CFoo::foo1(int arg, int arg2)
{
}

/**
 * CLASS:  CFoo
 * METHOD: foo2
 * TODO: DESCRIPTION
 * @return TODO
 */
int CFoo::foo2()
{
}

/**
 * CLASS:  CFoo
 * METHOD: operator +
 * TODO: DESCRIPTION
 * @return TODO
 */
int CFoo::operator +()
{
}

/**
 * CLASS:  $(fclass)
 * METHOD: func
 * TODO: DESCRIPTION
 * @return TODO
 */
map<string, int> func()
{
	// some codes
}

/**
 * CLASS:  $(fclass)
 * METHOD: some_func
 * TODO: DESCRIPTION
 * @return TODO
 */
int some_func(void)
{
}

