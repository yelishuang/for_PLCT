public class Cls
{
public void f();
} /* class Cls */
// no class end semicolon