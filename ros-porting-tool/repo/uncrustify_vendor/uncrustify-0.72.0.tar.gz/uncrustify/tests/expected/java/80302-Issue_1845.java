public class Version implements Comparable<Version> {

@Override
public int compareTo(@NonNull Version that) {
	return 0;
}
}
