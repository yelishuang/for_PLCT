public class Test {
public static void main() {
	btn.addActionListener(e->{
			System.exit(0);
		});
}
}