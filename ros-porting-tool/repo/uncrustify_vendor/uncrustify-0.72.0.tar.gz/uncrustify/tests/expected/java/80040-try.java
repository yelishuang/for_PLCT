public static void main(String[] args) {
	try (File file = new File("filename.txt"))
	{
		doit(processDefinition);
	}
}
