member.func(new List()
{{
   add("Text");
   add("Text",
       "Hello");
}});


private static final Set<String> VALID_CODES = new HashSet<String>()
{{
   add("XZ13s");
   add("AB21/X");
   add("YYLEX");
   add("AR2D");
}};

add(new JPanel()
{{
   setLayout(...);
   setBorder(...);
   add(new JLabel(...));
   add(new JSpinner(...));
}});

