public class LocalTests extends IosTest {
    /**
     * Check that app started up correctly. Then check that app continually runs for 5 seconds.
     * Then wait up to 20 seconds for the splash screen disappear.
     * @throws InterruptedException
     */
    @Test(groups = {"testdroid", "local"})
    public void checkAppForCrash() throws InterruptedException {
    }
}
