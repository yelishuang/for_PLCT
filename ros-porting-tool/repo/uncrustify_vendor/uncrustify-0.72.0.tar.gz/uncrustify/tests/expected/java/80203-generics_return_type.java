public class TestClass {
    public static <T> void executeRequest(final HttpUriRequest request, final ITestClassAPIResponseListener<T> responseListener) {
    }

    public <T extends YourType> T mymethod(T type) {
        return type;
    }
}
