new URL(url)
.
openConnection();
new URL(url)
.
openConnection();
