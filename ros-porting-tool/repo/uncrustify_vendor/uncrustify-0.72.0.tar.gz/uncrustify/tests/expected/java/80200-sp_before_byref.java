public static void method() {
	if (argA != null && argB != null) {
	}
	return (argA != null && argB != null);
}
