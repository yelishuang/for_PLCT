public class TestClassPrefetchData implements ITestClassAPIInputStreamResponseListener {
    private class TestClassPrefetchDataWrite extends AsyncTask<Void, Void, Void> {
    }
}
