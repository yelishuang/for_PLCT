public abstract class KeyValueItemWriter<K, V> implements ItemWriter<V>,
		                InitializingBean {}
//3456789=123456789=12
