Class definition:
public class A_Really_Really_Long_Class_Name extends
	Another_Really_Long_Class_Name {
}
