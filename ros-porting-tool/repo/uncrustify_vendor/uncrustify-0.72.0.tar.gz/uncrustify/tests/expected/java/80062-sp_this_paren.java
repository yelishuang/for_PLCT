public class JavaClass {
public JavaClass() {
	this (1);
}

public JavaClass(int i) {
	super (i);
}
}
