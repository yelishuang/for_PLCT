FMILIB_FMI1_Readme.txt
======================
Note that "fmiPlatformTypes.h" is used for compilation of FMILIB.
It is expected that its contents is consistent with the definitions 
in "fmiModelTypes.h". Therefore, make sure to provide all the 4 
header files (both ME and CS interfaces) if you are building for
non-standard platform.

All the 4 header files are used in FMILIB tests. 
