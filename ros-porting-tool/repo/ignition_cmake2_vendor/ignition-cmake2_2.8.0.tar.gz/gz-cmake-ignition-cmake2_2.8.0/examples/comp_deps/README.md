# component\_deps

A package with two components (`child` and `parent`) with a dependency
relationship between the components (`child` links against `parent`).
