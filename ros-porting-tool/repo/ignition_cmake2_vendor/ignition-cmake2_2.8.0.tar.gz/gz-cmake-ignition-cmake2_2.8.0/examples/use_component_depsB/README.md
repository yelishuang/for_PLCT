# use\_component\_depsB

This package uses the `child` and `parent` components of `component\_deps`
and calls `ign_find_package` with the components specified
in the order `child parent`.
Aside from the order in which the components are specified,
this package is identical to `use_component_depsA`.
