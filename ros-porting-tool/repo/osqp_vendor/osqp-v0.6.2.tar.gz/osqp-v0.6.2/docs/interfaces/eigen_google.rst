.. _eigen_google:

C++ Eigen interface (osqp-cpp)
================================

The Eigen interface developed at Google is documented `here <https://github.com/google/osqp-cpp>`_.
